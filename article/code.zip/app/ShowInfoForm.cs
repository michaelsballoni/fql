﻿using System;
using System.Windows.Forms;

namespace fql
{
    public partial class ShowInfoForm : Form
    {
        public ShowInfoForm()
        {
            InitializeComponent();
        }
    }
}
